<?php
function child_theme_scriptsandstyles () 
{
  wp_enqueue_style ( 'parent-style', get_template_directory().'/style.css',null,120);
  wp_enqueue_script ( 'jquery-min', 'https://code.jquery.com/jquery-1.9.1.min.js', 150,false);
  wp_enqueue_script ( 'custom', get_stylesheet_directory_uri().'/js/custom.js', 99,false);
  wp_localize_script( 'custom', 'templateUrl', array(  'ajaxurl' => admin_url( 'admin-ajax.php')));
  
}
add_action( 'wp_enqueue_scripts', 'child_theme_scriptsandstyles');
require get_stylesheet_directory().'/custom_posts.php';
function more_post_ajax(){
   // $catSlug = explode(',',$_POST['category']);
   // var_dump($catSlug);
	$offset = (isset($_POST['offset'])) ? $_POST['offset'] : 3;
    $pageNumber = (isset($_POST['pageNumber'])) ? $_POST['pageNumber'] : 0 ;

// var_dump($catid); 
  // header("Content-Type: text/html");
    $args = array( 
    	'post_type'       => 'sports', 
    	'posts_per_page'  => $offset,
    	'paged'			      => $pageNumber,
    	'tax_query'       => array( 'relation' => 'AND',));  
 	if(!empty(isset($_POST['category']))) {
   /* foreach( $_POST['category'] as $term ) {
          $space_terms[] = $term;
        }*/
		$arg =  array(
		      'taxonomy' 	  => 'Games',
					'field' 			=> 'term_id',
					'terms' 			=> $_POST['category'],
		         );	
		array_push($args['tax_query'],$arg);	
	}
	//var_dump($space_terms); 
		
    $loop = new WP_Query($args);
//var_dump( $args);
    //echo '<pre>';print_r($loop); echo '</pre>';

    //exit;
    if ($loop -> have_posts()) :  while ($loop -> have_posts()) : $loop -> the_post();?>
		<div class="display_post">
			<?php the_post_thumbnail(array(70,70));?>
		    <h6><?php the_title(); ?></h6>
		    <p><?php the_content(); ?></p>
		  </div>
<?php
    endwhile;
    endif;
    wp_reset_postdata();
    die();
}
add_action('wp_ajax_nopriv_more_post_ajax', 'more_post_ajax');
add_action('wp_ajax_more_post_ajax', 'more_post_ajax');



function date_picker_meta_box() {

    $screens = array( 'sports');

    foreach ( $screens as $screen ) {
        add_meta_box(
            'custom-date-picker',
            __( 'custom date picker', 'sitepoint' ),
            'meta_box_callback',
            $screen
        );
    }
}

add_action( 'add_meta_boxes', 'date_picker_meta_box' );

function meta_box_callback( $post ) {

    // Add a nonce field so we can check for it later.
    wp_nonce_field( 'global_notice_nonce', 'global_notice_nonce' );

    //$value = get_post_meta( $post->ID, 'date_of_post', true );

    /*echo '<input type="date" id="datepicker_start" name="ads_datetime_start" value="'.get_post_meta( get_the_ID(), 'date_of_post', true ).'"/>'; */?>
    <table>
    <tr>
    <td><label for="DOB">Birth Date</label>
        <input id="date"
            type="date"
            name="date"
           value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'date', true ) ); ?>">
    </td>
    </tr>
</table><?php
}

add_action( 'save_post', 'save_global_notice_meta_box_data' );

function save_global_notice_meta_box_data( $post_id ) 
{

    update_post_meta( $post_id, 'date', $_POST['date'] );
}
add_action( 'admin_enqueue_scripts', 'enqueue_date_picker'  );
function enqueue_date_picker(){
    wp_enqueue_script(
        'date-picker-js',
        plugins_url('/js/date_picker.js', __FILE__),
        array('jquery', 'jquery-ui-core', 'jquery-ui-datepicker'),
        time(),
        true
    );
    wp_enqueue_style( 'jquery-ui-datepicker' );
    wp_register_style( 'b-rapid-admin', plugins_url( __FILE__ ) . '/css/date_picker_style.css' );

}
