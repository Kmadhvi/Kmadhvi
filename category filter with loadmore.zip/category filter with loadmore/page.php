<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();
?>
	<div style="width: 100%;">
		<div style="width: 30%; float:left">
				<?php
            $args = array(
             'post_type'       => 'sports',
              'posts_per_page' => -1,
              'post_status'    => 'publish',
            );
            $posts_array = get_posts( $args );
            $total_post = count($posts_array);?>
          <form action="" method="get">
            <label>Search </label>
          <input type="text" placeholder="Search..." name="title" maxlength="15" value="<?php echo $_GET['title']?>">
          <label id="msg"></label></h2>
          <label>Start date</label>
    			<input type="date" name="start_date" value="<?php echo $_GET['start_date']?>"><br>
          <label>End Date</label>
          <input type="date" name="end_date" value="<?php echo $_GET['end_date']?>"><br>

              <?php $categories = get_categories(array('taxonomy' => 'Games')); ?>
    					<br><label>Categories</label><br>
    					 All (<?php echo $total_post ?>) <br>
    					<?php foreach( $categories as $cat ){
    						$cate = $cat->name ;?>
					<input type="checkbox" id="<?php echo $cat->term_id; ?>" name="category[]" class="cat-item" value="<?php echo $cat->slug ; ?>">
					<label for="<?php echo  $cate ; ?>"> <?php echo  $cate ; ?> (<?php echo $cat->count; ?>)</label><br>
						  <?php }?>


		    <input type="submit" name="submit" value="filter" id="btn">
	</form>
  <?php

  $keyword = $_GET['title']; 
  $start_date = $_GET['start_date'];
$end_date = $_GET['end_date'];

  ?>
	
	</div>
	<div style="width: 60%; float:right;"> 
<div id="ajax-posts" class="row">
        <?php
        $postsPerPage = 20;
            $args = array(
                    'post_type'      => 'sports',
                    'posts_per_page' =>  $postsPerPage,
                    's'              =>  $keyword,
                    'relation'       =>  'OR',
                    'meta_key'       =>  'date',
                    'meta_query'     =>  array(
                          'relation' =>  'AND',
                           array(
                              'key'     => 'date',
                              'value'   => $start_date,
                              'compare' => '>'
                           ),
                           array(
                              'key'     => 'date',
                              'value'   => $end_date,
                              'compare' => '<'
                           ),
                        ),
            );
            echo get_post_meta(get_the_ID(),'date',true);
            $loop = new WP_Query($args);
   
            while ($loop->have_posts()) : $loop->the_post();?>
   <div class="display_post">
	<?php the_post_thumbnail(array(70,70)); ?>
    <h6><?php the_title(); ?></h6>
    <p><?php the_content(); ?></p>
  </div><?php
                endwhile;
        wp_reset_postdata();
         ?>
    </div>
    <button id="more_posts" data-num=1>Load more</button>  


 </div>
</div>
	
 <?php
get_footer();
