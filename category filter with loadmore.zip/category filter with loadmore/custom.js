jQuery(document).ready(function() { 
var pageNumber  = 1;
var offset = 3 ; // Post per page
var checkboxes_value = [];
$(document).on('click','#more_posts',function(){   
  // var offset = $('.display_post').length;
   //alert(offset);
    $.each($(".cat-item:checked"), function(){  
         checkboxes_value.push( $(this).attr('id'));
    });    
    var check_id =  checkboxes_value.join(',') ; 
  var num = jQuery('#more_posts').data('num')+1;
//  alert(num);
  jQuery('#more_posts').data('num', num); 
//alert(num);
  $.ajax({
    method: 'POST',
    type: 'json',
    url: templateUrl.ajaxurl,
    data: {
      'action'     : 'more_post_ajax',
      'category'   : checkboxes_value,
      'offset'     : offset,
      'pageNumber' : num,

    },
    success: function(data) {
                  if(data){
                     jQuery("#ajax-posts").append(data);
                   
                       $('#more_posts').show();
                  }else
                  {
                   $('#more_posts').hide();
                  }
        }
  });
});
jQuery(".cat-item").change(function(){
    var offset = 3 ; // Post per page

 var num = 1;

  jQuery('#more_posts').data('num', num); 
   var checkboxes_value = [];    
    
    $.each($(".cat-item:checked"), function(){            
        //checkboxes_value .push($(this).val());
        checkboxes_value.push( $(this).attr('id') );
    }); 
    /*$('input:checkbox[class=cat-item]:checked').each(function() 
    {
       alert( $(this).attr('id') );
    });  */ 
  var check_id = checkboxes_value.join(',');
  $.ajax({
    method: 'POST',
    type: 'json',
    url: templateUrl.ajaxurl,
    data: {
       'action'     : 'more_post_ajax',
      'category'   : checkboxes_value,
      'offset'     : offset,
      'pageNumber' : num
    },
    success: function(data) {
                  if(data){
                     jQuery("#ajax-posts").html(data);
                       $('#more_posts').show();
                  }else
                  {
                   $('#more_posts').hide();
                  }  
        }
  });
});

});
