<?php

/**
 * The WpThemeOption Plugin
 
 * @subpackage Main
 */
/**
 * Plugin Name:       WpThemeOption
 * Plugin URI:        https://www.bytestechnolab.com/
 * Description:       WPeBooks of WordPress.
 * Author:            Bytes
 * Author URI:        https://www.bytestechnolab.com/
 * Version:           1.0.0
 * Text Domain:       wpthemeoption
 */

 function add_new_menu_items()
    {
        add_menu_page(
            "Social Media Options", 
            "Social Media Options", 
            "manage_options", 
            "theme-options", 
            "theme_options_page", 
            "dashicons-hammer", 
            90 
        );
    }
    function theme_options_page()
    {
        ?>
            <div class="wrap">
            <div id="icon-options-general" class="icon32"></div>
             <?php settings_errors();?>  
            <h1>Theme Options</h1>
            <form method="post" action="options.php">
                <?php
                    settings_fields("my_section");
                    do_settings_sections("theme-options"); 
                    submit_button();
                ?>         
            </form>
        </div>
        <?php
    }
       add_action("admin_menu", "add_new_menu_items");

    function display_options()
    {
       add_settings_section("my_section","My Section","display_my_section_options_content","theme-options");
       add_settings_field("wp_logo", "Social Media links ", "display_social_icons", "theme-options", "my_section");
       function handle_wp_logo_upload($option)
        {
                // do upload logic here
            if(!empty($_FILES["wp_logo"]["tmp_name"]))
            {
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                $urls = wp_handle_upload($_FILES['wp_logo'], array('test_form' => FALSE));
                $temp = $urls["url"];
                print_r($temp);
                return $temp; 
            }
            return get_option("wp_logo");
         }
            
    register_setting("my_section", "instagram");       
    register_setting("my_section", "facebook");
    register_setting("my_section", "twitter");
    register_setting("my_section", "youtube");
    register_setting("my_section", "linkdin");
    register_setting("my_section", "page_id");
    register_setting("my_section", "wp_logo");
  
   function display_my_section_options_content(){echo "This is my section of the theme";}

        function display_social_icons()
        { 
            wp_enqueue_media(); ?>
        <label>Instagram</label>
        <input type="text" name="instagram" id="instagram" value="<?php echo get_option('instagram'); ?>" /><br>
        <label>Facebook</label>
        <input type="text" name="facebook" id="facebook" value="<?php echo get_option('facebook'); ?>" /><br>
        <label>twitter</label>
        <input type="text" name="twitter" id="twitter" value="<?php echo get_option('twitter'); ?>"/><br>
        <label>youtube</label>
        <input type="text" name="youtube" id="youtube" value="<?php echo get_option('youtube'); ?>" /><br>
        <label>linkdin</label>
        <input type="text" name="linkdin" id="linkdin" value="<?php echo get_option('linkdin'); ?>" /><br>
        <label>Select Image</label>
        <a href="#" class="aw_upload_image_button button button-secondary"><?php _e('Upload Image_aw'); ?></a>
        <input type="text" name="wp_logo" id="wp_logo" value="<?php echo get_option('wp_logo'); ?>" style="width:500px;" /><br>
        <?php echo get_option('wp_logo');?><br>
        <lable>List of Posts</lable>
        <select name="page_id" id="page_id">
            <option value="<?php echo get_option('page_id'); ?>"><?php echo get_option('page_id'); ?></option>
            <?php
            global $post;
            $args = array( 'post_type' => 'post','numberposts' => -1);
            $posts = get_posts($args);
            foreach( $posts as $post ) : setup_postdata($post); ?>
                <option value="<?php the_title(); ?>"><?php the_title(); ?></option>
            <?php endforeach; ?>
            </select>
            <?php 


        }
    }

    add_action("admin_init", "display_options");

function multiselect_scripts() {

    wp_register_script( 'wp_theme_options', plugins_url( 'js/my-admin.js' , __FILE__ ), array('jquery'),null,true);
    wp_enqueue_script( 'wp_theme_options' );

}
add_action('admin_enqueue_scripts', 'multiselect_scripts',99);


/*add_action('admin_enqueue_scripts', 'uploader_javaScript');

function uploader_javaScript() {
 
  wp_enqueue_media();
  wp_register_script('theme_options',  plugin_dir_path( __FILE__ ) .'/my-admin.js', array('jquery'));
  wp_enqueue_script('theme_options');
 
}*/

/*
$layout       = get_option('wp_logo');
//echo $layout;
$facebook_url = get_option('facebook');
//echo $facebook_url;
$twitter_url  = get_option('twitter');


 add_shortcode('social_media' , 'social_media_callback');

function social_media_callback ()
{
   //$content .= '';    
  //$out .= '';
//$content .= '<div>'; ?>
<i class="fa fa-twitter"><a target="_blank" href="<?php echo get_option('facebook'); ?>" title="Twitter"></a></i>
<div class="header-social">
    <a target="_blank" href="<?php echo get_option('instagram'); ?>" title="Twitter"><i class="fa fa-twitter"></i></a>                     
    <a target="_blank" href="<?php echo get_option('facebook'); ?>" title="Facebook"><i class="fa fa-facebook"></i></a>                   
    <a target="_blank" href="<?php echo get_option('twitter'); ?>" title="Linkedin"><i class="fa fa-linkedin-square"></i></a>                                                            
    <a target="_blank" href="<?php echo get_option('youtube'); ?>" title="Instagram"><i class="fa fa-instagram"></i></a>                                                
    <a target="_blank" href="<?php echo get_option('linkdin'); ?>" title="Youtube"><i class="fa fa-youtube-play"></i></a>                                                        
  </div>

//$content.=  '<div> "'. get_option('instagram').'"</div>';
//$content.=  '<div>  "'. get_option('facebook').'"</div>';
//$content.=  '<div>  "'. get_option('twitter').'"</div>';
//$content.=  '<div>  "'. get_option('youtube').'"</div>';
//$content.=  '<div>  "'. get_option('linkdin').'"</div>';
//$content .= '</div>';
 //return $content;
   */
